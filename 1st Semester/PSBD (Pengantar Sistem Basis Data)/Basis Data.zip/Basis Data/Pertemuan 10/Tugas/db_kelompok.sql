-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 20, 2022 at 02:41 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tugas`
--

-- --------------------------------------------------------

--
-- Table structure for table `DetailGaji`
--

CREATE TABLE `DetailGaji` (
  `Nomor_Slip` INT(10) NOT NULL,
  `Kode_Potongan` INT(2) NOT NULL,
  `Jumlah` INT(10) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Gaji`
--

CREATE TABLE `Gaji` (
  `Nomor_Slip` INT(10) NOT NULL,
  `Tanggal` DATE NOT NULL,
  `Pendapatan` INT(12) NOT NULL,
  `Gaji_Bersih` INT(12) NOT NULL,
  `NIP` CHAR(6) NOT NULL,
  `Kode_Petugas` CHAR(8) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Golongan`
--

CREATE TABLE `Golongan` (
  `Golongan` CHAR(5) NOT NULL,
  `TJ_Suami_Istri` INT(12) NOT NULL,
  `TJ_Anak` INT(12) NOT NULL,
  `Uang_Makan` INT(12) NOT NULL,
  `Uang_Lembur` INT(12) NOT NULL,
  `Askes` VARCHAR(255) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Jabatan`
--

CREATE TABLE `Jabatan` (
  `Kode_Jabatan` CHAR(8) NOT NULL,
  `Nama_Jabatan` VARCHAR(255) NOT NULL,
  `Gaji_Pokok` INT(12) NOT NULL,
  `TJ_Jabatan` INT(12) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Pegawai`
--

CREATE TABLE `Pegawai` (
  `NIP` CHAR(6) NOT NULL,
  `Nama_Pegawai` VARCHAR(255) NOT NULL,
  `Kode_Jabatan` CHAR(8) NOT NULL,
  `Golongan` CHAR(5) NOT NULL,
  `Status` VARCHAR(10) NOT NULL,
  `Jumlah_Anak` INT(2) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Petugas`
--

CREATE TABLE `Petugas` (
  `Kode_Petugas` CHAR(8) NOT NULL,
  `Nama_Petugas` VARCHAR(255) NOT NULL,
  `Password_Petugas` VARCHAR(255) NOT NULL,
  `Status_Petugas` CHAR(10) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Potongan`
--

CREATE TABLE `Potongan` (
  `Kode_Potongan` INT(2) NOT NULL,
  `Nama_Potongan` VARCHAR(255) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `DetailGaji`
--
ALTER TABLE `DetailGaji`
  ADD PRIMARY KEY (`Nomor_Slip`),
  ADD UNIQUE KEY `Kode_Potongan` (`Kode_Potongan`);

--
-- Indexes for table `Gaji`
--
ALTER TABLE `Gaji`
  ADD PRIMARY KEY (`Nomor_Slip`),
  ADD UNIQUE KEY `NIP` (`NIP`,`Kode_Petugas`),
  ADD KEY `Kode_Petugas` (`Kode_Petugas`);

--
-- Indexes for table `Golongan`
--
ALTER TABLE `Golongan`
  ADD PRIMARY KEY (`Golongan`);

--
-- Indexes for table `Jabatan`
--
ALTER TABLE `Jabatan`
  ADD PRIMARY KEY (`Kode_Jabatan`);

--
-- Indexes for table `Pegawai`
--
ALTER TABLE `Pegawai`
  ADD PRIMARY KEY (`NIP`),
  ADD UNIQUE KEY `Kode_Jabatan` (`Kode_Jabatan`,`Golongan`),
  ADD KEY `Golongan` (`Golongan`);

--
-- Indexes for table `Petugas`
--
ALTER TABLE `Petugas`
  ADD PRIMARY KEY (`Kode_Petugas`);

--
-- Indexes for table `Potongan`
--
ALTER TABLE `Potongan`
  ADD PRIMARY KEY (`Kode_Potongan`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `DetailGaji`
--
ALTER TABLE `DetailGaji`
  ADD CONSTRAINT `DetailGaji_ibfk_1` FOREIGN KEY (`Nomor_Slip`) REFERENCES `Gaji` (`Nomor_Slip`),
  ADD CONSTRAINT `DetailGaji_ibfk_2` FOREIGN KEY (`Kode_Potongan`) REFERENCES `Potongan` (`Kode_Potongan`);

--
-- Constraints for table `Gaji`
--
ALTER TABLE `Gaji`
  ADD CONSTRAINT `Gaji_ibfk_1` FOREIGN KEY (`NIP`) REFERENCES `Pegawai` (`NIP`),
  ADD CONSTRAINT `Gaji_ibfk_2` FOREIGN KEY (`Kode_Petugas`) REFERENCES `Petugas` (`Kode_Petugas`);

--
-- Constraints for table `Jabatan`
--
ALTER TABLE `Jabatan`
  ADD CONSTRAINT `Jabatan_ibfk_1` FOREIGN KEY (`Kode_Jabatan`) REFERENCES `Pegawai` (`Kode_Jabatan`);

--
-- Constraints for table `Pegawai`
--
ALTER TABLE `Pegawai`
  ADD CONSTRAINT `Pegawai_ibfk_1` FOREIGN KEY (`Golongan`) REFERENCES `Golongan` (`Golongan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
