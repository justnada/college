-- Perintah Membuat Databse -- 
-- CREATE SCHEMA penjualan;

-- CREATE DATABASE jualan1;

-- Membuka Database
USE penjualan;

-- Menghapus Database
DROP DATABASE jualan1;
DROP TABLE detail_pesan;

-- Membuat Tabel Product
CREATE TABLE produk(
id_produk CHAR(5) NOT NULL,
nama_produk VARCHAR(30) NOT NULL,
satuan ENUM('Pcs','Unit','Rim','Pack') NOT NULL,
harga NUMERIC(10,0) NOT NULL DEFAULT '0',
stock INT(3)NOT NULL DEFAULT '0',
PRIMARY KEY(id_produk),
CONSTRAINT check_id_produk
CHECK(id_produk LIKE 'BR[0-9] [0-9] [0-9]'))
ENGINE=INNODB DEFAULT CHARSET = latin1;


-- Membuat Tabel Pelanggan
CREATE TABLE pelanggan(
id_pelanggan CHAR(5) NOT NULL,
nama_pelanggan VARCHAR(30) NOT NULL,
alamat TEXT NOT NULL,
telepon VARCHAR(15) NOT NULL,
email VARCHAR(20) NOT NULL,
PRIMARY KEY(id_pelanggan),
CONSTRAINT check_id_pelanggan
CHECK(id_pelanggan LIKE 'PL[0-9] [0-9] [0-9]'))
ENGINE=INNODB DEFAULT CHARSET = latin1;

-- Membuat Tabel Pesan
CREATE TABLE pesan(
id_pesan CHAR(8) NOT NULL,
id_pelanggan CHAR(5) NOT NULL,
tgl_pesan DATE NOT NULL,
PRIMARY KEY(id_pesan),
KEY id_pelanggan(id_pelanggan),
CONSTRAINT pesan FOREIGN KEY (id_pelanggan)
REFERENCES pelanggan(id_pelanggan)
ON DELETE CASCADE ON UPDATE CASCADE)
ENGINE=INNODB DEFAULT CHARSET = latin1;

-- Membuat Tabel Detail Pesan
CREATE TABLE detail_pesan(
id_pesan CHAR(8) NOT NULL,
id_produk CHAR(8) NOT NULL,
jumlah INT(5) NOT NULL DEFAULT '0',
subtotal NUMERIC(10,0) NOT NULL DEFAULT '0',
PRIMARY KEY(id_pesan,id_produk),
KEY fk_detail_pesan(id_produk),
KEY fk_detail_pesan2(id_pesan),
CONSTRAINT fk_detail_pesan FOREIGN KEY(id_produk)
REFERENCES produk(id_produk),
CONSTRAINT fk_detail_pesan2 FOREIGN KEY(id_pesan)
REFERENCES pesan(id_pesan))
ENGINE=INNODB DEFAULT CHARSET = latin1;


CREATE TABLE faktur(
id_faktur CHAR(9) NOT NULL,
id_pesan CHAR(8) NOT NULL,
tgl_faktur DATE NOT NULL,
PRIMARY KEY (id_faktur),
KEY fk_faktur(id_pesan),
CONSTRAINT fk_faktur FOREIGN KEY (id_pesan)
REFERENCES pesan(id_pesan))
ENGINE=INNODB DEFAULT CHARSET = latin1;

CREATE TABLE kuitansi(
id_kuitansi CHAR(5) NOT NULL,
id_faktur CHAR(9) NOT NULL,
tgl_kutiansi DATE NOT NULL,
PRIMARY KEY (id_kuitansi),
KEY fk_kuitansi(id_faktur),
CONSTRAINT fk_kuitansi FOREIGN KEY (id_faktur)
REFERENCES faktur(id_faktur))
ENGINE=INNODB DEFAULT CHARSET = latin1;


CREATE VIEW data_plg AS
(SELECT id_pelanggan,nama_pelanggan,telepon FROM pelanggan 
ORDER BY nama_pelanggan);

SELECT * FROM data_plg;

ALTER VIEW data_plg AS
(SELECT * FROM pelanggan ORDER BY nama_pelanggan);

DROP VIEW data_plg;


ALTER TABLE pelanggan DROP CONSTRAINT check_id_pelanggan

INSERT INTO pelanggan VALUES ('PL001','Reva Ragam','Jakarta Selatan','0214288376','revasa@gmail.com');
INSERT INTO pelanggan VALUES ('PL002','prameswari','Jakarta Pusat','02142883377','prameswari@yahoo.com');
INSERT INTO pelanggan VALUES ('PL003','Adit','Jakarta Barat','0215883377','adit_ok@gmail.com');
INSERT INTO pelanggan VALUES ('PL004','Rafania','Bintaro','02172883376','rafa_chubby@gmail.com');
INSERT INTO pelanggan VALUES ('PL005','Livia','Jakarta Timur','02167883376','livia_cute@hotmail.com');

SELECT * FROM pelanggan



ALTER TABLE produk DROP CONSTRAINT check_id_produk

INSERT INTO produk VALUES ('BR001','Printer Canon','unit',650000,10);
INSERT INTO produk VALUES ('BR002','Netbook Asus 14','unit',5000000,3);
INSERT INTO produk VALUES ('BR003','Mouse+keyboard set','unit',180000,4);
INSERT INTO produk VALUES ('BR004','Speaker Simbadda','unit',350000,3);
INSERT INTO produk VALUES ('BR005','Earphone','unit',100000,5);

SELECT * FROM produk




INSERT INTO pesan VALUES ('PO190401','PL004','2022/08/20');
INSERT INTO pesan VALUES ('PO190402','PL002','2022/08/20');
INSERT INTO pesan VALUES ('PO190403','PL001','2022/08/20');

SELECT * FROM pesan




INSERT INTO detail_pesan VALUES ('PO190401','BR002',1,5000000);
INSERT INTO detail_pesan VALUES ('PO190402','BR005',1,100000);
INSERT INTO detail_pesan VALUES ('PO190403','BR003',1,180000);
INSERT INTO detail_pesan VALUES ('PO190401','BR005',1,100000);
INSERT INTO detail_pesan VALUES ('PO190402','BR001',1,650000);
INSERT INTO detail_pesan VALUES ('PO190402','BR002',1,5000000);

SELECT * FROM detail_pesan



INSERT INTO faktur VALUES ('F1904001','PO190401','2022/08/20');
INSERT INTO faktur VALUES ('F1904002','PO190402','2022/08/20');
INSERT INTO faktur VALUES ('F1904003','PO190403','2022/08/20');

SELECT * FROM faktur 



INSERT INTO kuitansi VALUES ('K0401','F1904001','2022/08/20');
INSERT INTO kuitansi VALUES ('K0402','F1904002','2022/08/20');
INSERT INTO kuitansi VALUES ('K0403','F1904003','2022/08/20');

SELECT * FROM kuitansi

SELECT * FROM detail_pesan